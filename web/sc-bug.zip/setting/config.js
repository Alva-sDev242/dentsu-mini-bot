const fs = require('fs')

global.owner = "242068570352" //owner number
global.footer = "DENTSU_CRASH" //footer section
global.status = true //"self/public" section of the bot
global.prefa = ['.','😈']
global.owner = ['242053323191']
global.xprefix = '.','','!','?'
global.gambar = "https://files.catbox.moe/y05o1b.jpg"
global.OWNER_NAME = "@Natsu_or_Dentsu" //
global.DEVELOPER = ["6405611529"] //
global.BOT_NAME = "DENTSU_CRASH"
global.bankowner = "NATSUorDENTSU"
global.creatorName = "natsu"
global.ownernumber = '242068570352'  //creator number
global.antilink = true / false
global.location = "Nigeria,Congob"
global.prefa = ['.','😈']
//================DO NOT CHANGE OR YOU'LL GET AN ERROR=============\
global.footer = "Killer" //footer section
global.link = "https://chat.whatsapp.com/BEedoSwSIcaLd1TaM9qxBo?mode=gi_t"
global.autobio = false//auto update bio
global.botName = "DENTSU_CRASH"
global.version = "V2"
global.botname = "DENTSU_CRASH"
global.author = "NATSUorDENTSU"
global.themeemoji = '🥺'
global.wagc = 'https://chat.whatsapp.com/BEedoSwSIcaLd1TaM9qxBo?mode=gi_t'
global.thumbnail = 'https://files.catbox.moe/y05o1b.jpg'
global.richpp = 'https://files.catbox.moe/b0xvcj.jpg'
global.packname = "Sticker By Dark Net"
global.author = "\n\n\n\n\nCreated by Killer\ntelegram : @Natsu_or_Dentsu"
global.creator = "242068570352@s.whatsapp.net"
global.ownername = 'NATSUorDENTSU' 
global.onlyowner = `𝘴𝘰𝘳𝘳𝘺 𝘰𝘯𝘭𝘺 𝘧𝘰𝘳  𝘰𝘸𝘯𝘦𝘳𝘴
𝘤𝘰𝘯𝘵𝘢𝘤𝘵 Dark Net 𝘵𝘰 𝘣𝘦 𝘢𝘯 𝘰𝘸𝘯𝘦𝘳`
  // reply 
global.database = `𝘛𝘰 𝘣𝘦 𝘪𝘯  𝘥𝘢𝘵𝘢𝘣𝘢𝘴𝘦 𝘣𝘢𝘴𝘦 𝘤𝘰𝘯𝘵𝘢𝘤𝘵 Dark Net*`
  global.mess = {
wait: "```𝗪𝗔𝗜𝗧......```",
   success: "𝑺𝒖𝒄𝒄𝒆𝒔𝒔",
   on: "DARK MD is active", 
   prem: "FOR PREMIUM USERS ONLY ADD YOUR NUMBER TO DATABASE TO ACCESS PREMIUM", 
   off: "off",
   query: {
       text: "Where's the text?",
       link: "Where's the link?",
   },
   error: {
       fitur: "Sorry, bro, the feature has error. Please chat with the Bot Developer so it can be fixed immediately.",
   },
   only: {
       group: "Sorry, This Feature Can Only Be Used In Groups only",
private: "Sorry, This Feature Can Only Be Used In Private Chats",
       owner: "Sorry, This Feature Can Only Be Used by DarkNet",
       admin: " Sorry, this feature can only be used by Bot Admins",
       badmin: "Sorry, bro, It Looks Like You Can't Use This Feature Because the Bot is Not yet Group Admin",
       premium: "This feature is specifically for DarkNet beloved Premium users",
   }
}

global.hituet = 0
//false=disable and true=enable
global.autoRecording = false //auto recording
global.autoTyping = false //auto typing
global.autorecordtype = false //auto typing + recording
global.autoread = false //auto read messages
global.autobio = false //auto update bio
global.anti92 = false //auto block +92 
global.autoswview = true //auto view status/story

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
